package com.example.finalproject_amritrathi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ReportBirdSightingActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonSubmit;
    EditText editTextbirdname, editTextzipcode;
    int counter = 0;

    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    String email = user.getEmail();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_bird_sighting);

        buttonSubmit = findViewById(R.id.buttonSubmit);

        editTextbirdname = findViewById(R.id.editTextbirdname);
        editTextzipcode = findViewById(R.id.editTextzipcode);

        buttonSubmit.setOnClickListener(this);

    }

    //Implementing the onclicklistener
    @Override
    public void onClick(View view) {

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("birdsightings");

        if (view == buttonSubmit) {

            if (editTextbirdname.getText().toString().trim().equalsIgnoreCase("")) {
                editTextbirdname.setError("This field can not be blank. Please enter a bird name.");

            } else if (editTextzipcode.getText().toString().trim().equalsIgnoreCase("")) {
                editTextzipcode.setError("This field can not be blank.Please enter a zipcode.");

            } else {

                String Birdname = editTextbirdname.getText().toString();
                String Zipcode = editTextzipcode.getText().toString();
                String PersonName = email;
                int Importance = counter;


                BirdSighting createBirdsighting = new BirdSighting(Birdname, Zipcode, PersonName, Importance);
                myRef.push().setValue(createBirdsighting);

            }
        }
    }


    //Code to bring in menu to this activity page
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.mainmenu,menu);

        return super.onCreateOptionsMenu(menu);
    }



    //Code to navigate menu items when selected accordingly


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == R.id.itemReportBirdsighting){

            Toast.makeText(this, "You are already in Report page.", Toast.LENGTH_SHORT).show();

        } else if (item.getItemId() == R.id.itemSearchBirdsighting) {

            Intent searchpageintent = new Intent(this,SearchBirdSightingActivity.class);
            startActivity(searchpageintent);

        } else if (item.getItemId() == R.id.itemLogout){

            FirebaseAuth.getInstance().signOut();
            Toast.makeText(this, "Logout successful", Toast.LENGTH_LONG).show();

            Intent logoutintent = new Intent(this,LoginPageActivity.class);
            startActivity(logoutintent);
        }

        return super.onOptionsItemSelected(item);

    }

}
