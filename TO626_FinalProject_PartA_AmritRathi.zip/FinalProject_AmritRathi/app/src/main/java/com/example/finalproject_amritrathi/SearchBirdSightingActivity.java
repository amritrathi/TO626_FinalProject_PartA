package com.example.finalproject_amritrathi;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SearchBirdSightingActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonSearch, buttonAddImportance;
    EditText editTextzipcodesearch;
    TextView textViewShowBirdName, textViewShowPersonName;

    //Add Importance Counter Starts from 0
    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_bird_sighting);


        buttonSearch = findViewById(R.id.buttonSearch);
        buttonAddImportance = findViewById(R.id.buttonAddImportance);

        editTextzipcodesearch = findViewById(R.id.editTextzipcodesearch);

        textViewShowBirdName = findViewById(R.id.textViewShowBirdName);
        textViewShowPersonName = findViewById(R.id.textViewShowPersonName);

        buttonSearch.setOnClickListener(this);
        buttonAddImportance.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        // Write a message to the database

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference myRef = database.getReference("birdsightings");

        if (view == buttonSearch) {

            if (editTextzipcodesearch.getText().toString().trim().equalsIgnoreCase("")) {
                editTextzipcodesearch.setError("This field cannot be blank. Please enter a valid zipcode");

            } else {

                String findZipcode = editTextzipcodesearch.getText().toString();

                myRef.orderByChild("Zipcode").limitToLast(1).equalTo(findZipcode).addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                        BirdSighting foundBirdsighting = dataSnapshot.getValue(BirdSighting.class);
                        String findBirdname = foundBirdsighting.Birdname;
                        String findPersonName = foundBirdsighting.PersonName;

                        textViewShowBirdName.setText(findBirdname);
                        textViewShowPersonName.setText(findPersonName);

                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        } else if (view == buttonAddImportance) {

            if (editTextzipcodesearch.getText().toString().trim().equalsIgnoreCase("")) {
                editTextzipcodesearch.setError("This field cannot be blank. Please enter a valid zipcode.");

            } else {

            String findZipcode = editTextzipcodesearch.getText().toString();

            counter++;
            int addimportance = counter;
            final int editImportance = addimportance;

            myRef.orderByChild("Zipcode").limitToLast(1).equalTo(findZipcode).addChildEventListener(new ChildEventListener() {

                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    String editKey = dataSnapshot.getKey();
                    //Book editBook = dataSnapshot.getValue(Book.class);
                    myRef.child(editKey).child("Importance").setValue(editImportance);

                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mainmenu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == R.id.itemReportBirdsighting){

            Intent reportpageintent = new Intent(this,ReportBirdSightingActivity.class);
            startActivity(reportpageintent);

        } else if (item.getItemId() == R.id.itemSearchBirdsighting) {

            Toast.makeText(this, "You are already in Search page.", Toast.LENGTH_SHORT).show();

        } else if (item.getItemId() == R.id.itemLogout){

            FirebaseAuth.getInstance().signOut();
            Toast.makeText(this, "Logout successful", Toast.LENGTH_LONG).show();

            Intent logoutintent = new Intent(this,LoginPageActivity.class);
            startActivity(logoutintent);
        }

        return super.onOptionsItemSelected(item);
    }
}