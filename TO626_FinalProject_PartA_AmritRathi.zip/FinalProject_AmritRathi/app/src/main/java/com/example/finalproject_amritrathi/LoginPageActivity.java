package com.example.finalproject_amritrathi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginPageActivity extends AppCompatActivity implements View.OnClickListener {
    //Creating button and edittext objects
    Button buttonLogin, buttonRegister;
    EditText editTextEmail, editTextPassword;

    //Creating Firebase authentication object
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Declaring button and edittext objects
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);

        //Setting buttons to onclicklistner
        buttonLogin.setOnClickListener(this);
        buttonRegister.setOnClickListener(this);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();



    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {

            Toast.makeText(LoginPageActivity.this, "Nobody is logged in", Toast.LENGTH_SHORT).show();

        } else {

            Toast.makeText(LoginPageActivity.this, "Somebody is already logged in", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void onClick(View view) {
        String email = editTextEmail.getText().toString();
        String password = editTextPassword.getText().toString();

        if (view == buttonRegister) {

            if (editTextEmail.getText().toString().isEmpty() || editTextPassword.getText().toString().isEmpty()) {

                Toast.makeText(LoginPageActivity.this, "Registration Fail. Please enter valid email and/or valid 6 character password", Toast.LENGTH_SHORT).show();

            } else {

                makeNewUsers(editTextEmail.getText().toString(), editTextPassword.getText().toString());

            }
        } else if (view == buttonLogin) {

            if (editTextEmail.getText().toString().isEmpty() || editTextPassword.getText().toString().isEmpty()) {

                Toast.makeText(LoginPageActivity.this, "Login Fail. Please enter valid email and/or valid 6 character password", Toast.LENGTH_SHORT).show();

            } else {

                LoginUsers(editTextEmail.getText().toString(), editTextPassword.getText().toString());

            }
        }
    }

    private void LoginUsers(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {

                            // Sign in success, update UI with the signed-in user's information
                            successfulSignIn();

                        } else {

                            // If sign in fails, display a message to the user.
                            Toast.makeText(LoginPageActivity.this, "Login Fail. Please enter valid email and 6 character password", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


    private void makeNewUsers(String email, String password) {

    //Code to register people
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {

                            // Sign in success, update UI with the signed-in user's information (also refers to checking to see if valid for Firebase Authentication)
                            makeNewUsers(editTextEmail.getText().toString(), editTextPassword.getText().toString());

                        } else {

                            // If sign in fails, display a message to the user.
                            Toast.makeText(LoginPageActivity.this, "Registration failed or you have already registered ", Toast.LENGTH_SHORT).show();
                                }
                    }
                });
    }

    private void successfulSignIn() {

        Intent loginIntent = new Intent(this, ReportBirdSightingActivity.class);
        startActivity(loginIntent);
        Toast.makeText(this, "Log In Successful", Toast.LENGTH_SHORT).show();

    }
}



