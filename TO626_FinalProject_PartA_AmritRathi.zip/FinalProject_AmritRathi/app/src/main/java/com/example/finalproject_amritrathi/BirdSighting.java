package com.example.finalproject_amritrathi;

public class BirdSighting {
    public String Birdname;
    public String Zipcode;
    public String PersonName;
    public int Importance;

    public BirdSighting() {
    }

    public BirdSighting(String Birdname, String Zipcode, String PersonName, int Importance) {
        this.Birdname = Birdname;
        this.Zipcode = Zipcode;
        this.PersonName = PersonName;
        this.Importance = Importance;
    }
}
